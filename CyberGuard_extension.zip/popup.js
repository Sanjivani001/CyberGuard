document.getElementById('scan').addEventListener('click', ()=>{
  const statusEl = document.getElementById('status');
  const resultsEl = document.getElementById('results');
  const lastEl = document.getElementById('lastUpdated');
  statusEl.innerText = 'Scanning...';
  resultsEl.innerHTML = '';
  // Query tabs directly from the popup (more reliable than letting the service worker query)
    // Query all tabs — using {currentWindow:true} from the popup often returns the popup window (no tabs).
    chrome.tabs.query({}, (tabsRaw) => {
      console.log('[popup] tabsRaw count:', (tabsRaw && tabsRaw.length) || 0);
      if (!tabsRaw || tabsRaw.length === 0) {
        // Fallback: if popup cannot see tabs, ask background service worker to try scanning (may have broader privileges)
        statusEl.innerText = 'No tabs found locally — requesting background scan...';
        chrome.runtime.sendMessage({ cmd: 'scanOpenTabs' }, resp => {
          if (!resp) {
            statusEl.innerText = 'No response from extension (fallback)';
            return;
          }
          if (!resp.ok) {
            statusEl.innerText = 'Fallback scan failed: ' + (resp.error || 'unknown');
            return;
          }

          statusEl.innerText = 'Scan complete (fallback)';
          const tabs = resp.tabs || [];
          lastEl.innerText = 'Last: ' + new Date().toLocaleString();
          renderResults(tabs, resultsEl);
        });
        return;
      }

      const tabsToScan = tabsRaw.filter(t => t.url && !t.url.startsWith('chrome://') && !t.url.startsWith('chrome-extension://')).map(t => ({ url: t.url, title: t.title || '' }));
      if (!tabsToScan || tabsToScan.length === 0) {
        // If popup sees only system or blocked pages, attempt background fallback
        statusEl.innerText = 'No user tabs found locally — requesting background scan...';
        chrome.runtime.sendMessage({ cmd: 'scanOpenTabs' }, resp => {
          if (!resp) {
            statusEl.innerText = 'No response from extension (fallback)';
            return;
          }
          if (!resp.ok) {
            statusEl.innerText = 'Fallback scan failed: ' + (resp.error || 'unknown');
            return;
          }

          statusEl.innerText = 'Scan complete (fallback)';
          const tabs = resp.tabs || [];
          lastEl.innerText = 'Last: ' + new Date().toLocaleString();
          renderResults(tabs, resultsEl);
        });
        return;
      }

      // Send the list of tabs to the background service worker to perform scanning (keeps UI responsive)
      chrome.runtime.sendMessage({ cmd: 'scanUrls', tabs: tabsToScan }, resp => {
        if (!resp) {
          statusEl.innerText = 'No response from extension';
          return;
        }
        if (!resp.ok) {
          statusEl.innerText = 'Scan failed: ' + (resp.error || 'unknown');
          return;
        }

        statusEl.innerText = 'Scan complete';
        const tabs = resp.tabs || [];
        lastEl.innerText = 'Last: ' + new Date().toLocaleString();
        renderResults(tabs, resultsEl);
      });
    });

  // Small helper to render results table
  function renderResults(tabs, resultsEl) {
    resultsEl.innerHTML = '';
    if (!tabs || tabs.length === 0) {
      resultsEl.innerHTML = '<div style="color:#666">No tabs found or tabs blocked by browser.</div>';
      return;
    }

    const table = document.createElement('table');
    table.style.width = '100%';
    table.style.borderCollapse = 'collapse';
    table.innerHTML = '<thead><tr><th style="text-align:left">Title</th><th style="text-align:left">URL</th><th style="text-align:center">Risk</th></tr></thead>';
    const tbody = document.createElement('tbody');

    tabs.forEach(t => {
      const tr = document.createElement('tr');
      const titleTd = document.createElement('td');
      titleTd.style.padding = '6px 4px';
      titleTd.innerText = t.title || '(no title)';

      const urlTd = document.createElement('td');
      urlTd.style.padding = '6px 4px';
      urlTd.style.wordBreak = 'break-all';
      urlTd.innerText = t.url || '';

      const riskTd = document.createElement('td');
      riskTd.style.textAlign = 'center';
      riskTd.style.padding = '6px 4px';
      const score = typeof t.riskScore === 'number' ? t.riskScore : 0;
      const span = document.createElement('span');
      span.innerText = score;
      span.style.padding = '4px 8px';
      span.style.borderRadius = '4px';
      span.style.color = '#fff';
      if (score >= 50) span.style.backgroundColor = '#dc3545';
      else if (score >= 25) span.style.backgroundColor = '#ffc107';
      else span.style.backgroundColor = '#28a745';
      riskTd.appendChild(span);

      tr.appendChild(titleTd);
      tr.appendChild(urlTd);
      tr.appendChild(riskTd);
      tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    resultsEl.appendChild(table);
  }
    if (!tabsRaw || tabsRaw.length === 0) {
      statusEl.innerText = 'No tabs found or tabs blocked by browser.';
      return;
    }

    const tabsToScan = tabsRaw.filter(t => t.url && !t.url.startsWith('chrome://') && !t.url.startsWith('chrome-extension://')).map(t => ({ url: t.url, title: t.title || '' }));
    console.log('[popup] user tabs filtered count:', tabsToScan.length);
    if (!tabsToScan || tabsToScan.length === 0) {
      statusEl.innerText = 'No tabs found or tabs blocked by browser.';
      return;
    }

    // Send the list of tabs to the background service worker to perform scanning (keeps UI responsive)
    chrome.runtime.sendMessage({ cmd: 'scanUrls', tabs: tabsToScan }, resp => {
      if (!resp) {
        statusEl.innerText = 'No response from extension';
        return;
      }
      if (!resp.ok) {
        statusEl.innerText = 'Scan failed: ' + (resp.error || 'unknown');
        return;
      }

      statusEl.innerText = 'Scan complete';
      const tabs = resp.tabs || [];
    lastEl.innerText = 'Last: ' + new Date().toLocaleString();

    if (tabs.length === 0) {
      resultsEl.innerHTML = '<div style="color:#666">No tabs found or tabs blocked by browser.</div>';
      return;
    }

    // Build simple table
    const table = document.createElement('table');
    table.style.width = '100%';
    table.style.borderCollapse = 'collapse';
    table.innerHTML = '<thead><tr><th style="text-align:left">Title</th><th style="text-align:left">URL</th><th style="text-align:center">Risk</th></tr></thead>';
    const tbody = document.createElement('tbody');

    tabs.forEach(t => {
      const tr = document.createElement('tr');
      const titleTd = document.createElement('td');
      titleTd.style.padding = '6px 4px';
      titleTd.innerText = t.title || '(no title)';

      const urlTd = document.createElement('td');
      urlTd.style.padding = '6px 4px';
      urlTd.style.wordBreak = 'break-all';
      urlTd.innerText = t.url || '';

      const riskTd = document.createElement('td');
      riskTd.style.textAlign = 'center';
      riskTd.style.padding = '6px 4px';
      const score = typeof t.riskScore === 'number' ? t.riskScore : 0;
      const span = document.createElement('span');
      span.innerText = score;
      span.style.padding = '4px 8px';
      span.style.borderRadius = '4px';
      span.style.color = '#fff';
      if (score >= 50) span.style.backgroundColor = '#dc3545';
      else if (score >= 25) span.style.backgroundColor = '#ffc107';
      else span.style.backgroundColor = '#28a745';
      riskTd.appendChild(span);

      tr.appendChild(titleTd);
      tr.appendChild(urlTd);
      tr.appendChild(riskTd);
      tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    resultsEl.appendChild(table);
  });
});

